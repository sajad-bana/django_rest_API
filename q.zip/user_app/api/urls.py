from django.urls import path, include
from user_app.api.views import user_list, user_details

urlpatterns = [
    path('list/', user_list, name='users-list'),
    path('<int:pk>/', user_details, name='user-details'),
]